"""The MCP adapter: eight tools over stdio, and the one thread they run on.

Two things live here and nothing else does. The first is the envelope: a tool
call goes in as a name and an argument dict, and comes back as a JSON text
block (plus an image block when a screenshot was taken). Every failure —
including one the session raised — comes back inside that normal result
rather than as an MCP protocol error, because a model that receives an
exception can only give up, while one that receives `{"ok": false, "error":
"stale_ref: ..."}` knows to look again.

The second is `Worker`. On Windows, `uiautomation` binds COM to the first
thread that uses it, and every later call from another thread either fails or
returns nonsense. So the backend is constructed on one dedicated thread and
every subsequent backend, browser and session call is submitted to that same
thread for the life of the process. The asyncio handler awaits the result, so
the event loop stays free to answer pings and cancellations while a step runs.

The session itself holds no lock; the single worker is what makes that safe.
`hands_request_permit` runs there too — a wait of up to 55 seconds serialises
behind everything else, which is correct for a client that issues one tool
call at a time and is waiting for a human anyway.
"""
from __future__ import annotations

import argparse
import asyncio
import base64
import json
import os
import signal
import uuid
from concurrent.futures import ThreadPoolExecutor

import mcp.types as t
from mcp.server import Server

from firekeep_client import hooklog

from . import __version__
from .backends import load_backend
from .backends.base import HandsError
from .broker.client import BrokerClient
from .browser import Browser
from .config import load_config, load_policy
from .ids import machine_id
from .keep import KeepLink
from .session import HandsSession

SERVER_NAME = "firekeep-hands"

TOOLS = [
    t.Tool(
        name="hands_status",
        description=(
            "What Hands can do on this machine right now: platform, permissions, "
            "approval broker, current task."
        ),
        inputSchema={"type": "object", "properties": {}},
    ),
    t.Tool(
        name="hands_task_start",
        description=(
            "Begin an operator task. Declares the goal and the apps you expect to touch; "
            "acting in any app outside them — clicking, typing, a keystroke, not just "
            "switching to it — is a boundary step that needs approval. Approving one "
            "adds that app to this task for the rest of it, so declare what you know "
            "you need and you will not be asked again. Use \"browser\" for web steps."
        ),
        inputSchema={
            "type": "object",
            "required": ["goal"],
            "properties": {
                "goal": {"type": "string"},
                "apps": {"type": "array", "items": {"type": "string"}},
            },
        },
    ),
    t.Tool(
        name="hands_observe",
        description=(
            "Look at the screen: the active window's interactive controls with refs you "
            "can act on. detail=summary|controls|screenshot."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "detail": {"type": "string", "enum": ["summary", "controls", "screenshot"]},
                "app": {"type": "string"},
                "region": {"type": "array", "items": {"type": "integer"},
                           "minItems": 4, "maxItems": 4},
                # The ceiling here is the shipped `HandsConfig.max_nodes`; the
                # session clamps to whatever THIS machine has configured, so
                # the schema is the advertised bound and the session is the
                # enforced one.
                "max_nodes": {"type": "integer", "minimum": 1, "maximum": 200},
            },
        },
    ),
    t.Tool(
        name="hands_find",
        description=(
            "Find controls by name/value text in the active window (or a named app). "
            "Refs from hands_find are actable until the next act."
        ),
        inputSchema={
            "type": "object",
            "required": ["query"],
            "properties": {
                "query": {"type": "string"},
                "role": {"type": "string"},
                "app": {"type": "string"},
                "limit": {"type": "integer", "minimum": 1, "maximum": 50},
            },
        },
    ),
    t.Tool(
        name="hands_act",
        description=(
            "Do one thing: {kind: invoke|set_value|click|type|key|scroll|focus_app|open_app|"
            "open_url|clipboard_set|wait, ...}. Refs come from hands_observe/hands_find; raw "
            "coordinates are refused. A protected step returns needs_permit — call "
            "hands_request_permit, then repeat the same action with permit=<challenge>. "
            "type has no ref, so it is judged against the control you last clicked; that "
            "is best-effort, and focus can move without Hands knowing."
        ),
        inputSchema={
            "type": "object",
            "required": ["action"],
            "properties": {
                "action": {"type": "object"},
                "permit": {"type": "string"},
            },
        },
    ),
    t.Tool(
        name="hands_request_permit",
        description=(
            "Wait for the human to approve a protected step (chord on the keyboard or a tap "
            "on the dashboard). Returns the permit state."
        ),
        inputSchema={
            "type": "object",
            "required": ["challenge"],
            "properties": {
                "challenge": {"type": "string"},
                "wait_s": {"type": "integer"},
            },
        },
    ),
    t.Tool(
        name="hands_browser",
        description=(
            "Operate the Hands-managed browser: op=open|tabs|navigate|read|find|click|fill|"
            "screenshot. Navigating to a host outside the allowlist is a boundary step, and "
            "so is clicking or filling unless the task declared \"browser\" in its apps — "
            "declare it up front, or approve the first one and the rest are not re-prompted. "
            "navigate always acts on the current tab; tab is ignored for it in this release."
        ),
        inputSchema={
            "type": "object",
            "required": ["op"],
            # Closed on purpose: everything this tool honours is declared, so
            # an argument that is not here is a mistake worth telling the
            # caller about rather than one silently dropped on the floor.
            "additionalProperties": False,
            "properties": {
                "op": {"type": "string",
                       "enum": ["open", "tabs", "navigate", "read", "find",
                                "click", "fill", "screenshot"]},
                "url": {"type": "string"},
                "ref": {"type": "string"},
                "text": {"type": "string"},
                "query": {"type": "string"},
                "limit": {"type": "integer", "minimum": 1, "maximum": 50},
                "tab": {"type": "string"},
                "permit": {"type": "string"},
            },
        },
    ),
    t.Tool(
        name="hands_task_end",
        description=(
            "Finish the task: outcome=done|failed|abandoned with a one-line summary. "
            "Releases the machine lease and closes the evidence ledger."
        ),
        inputSchema={
            "type": "object",
            "required": ["outcome"],
            "properties": {
                "outcome": {"type": "string", "enum": ["done", "failed", "abandoned"]},
                "summary": {"type": "string"},
            },
        },
    ),
]


class Worker:
    """One thread, for the life of the process, for every backend call.

    A `ThreadPoolExecutor` with `max_workers=1` spawns its thread on the
    first submission and keeps it — so whatever is submitted first is what
    binds COM, which is why `build_session` (and the `load_backend()` inside
    it) has to be the very first thing to go through here."""

    def __init__(self):
        self.pool = ThreadPoolExecutor(max_workers=1, thread_name_prefix="hands-backend")

    def run(self, fn, *args, **kwargs):
        """Synchronously, on the worker thread. Exceptions propagate to the
        caller unchanged."""
        return self.pool.submit(fn, *args, **kwargs).result()

    async def call(self, fn, *args, **kwargs):
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(self.pool, lambda: fn(*args, **kwargs))

    def shutdown(self) -> None:
        self.pool.shutdown(wait=False)


def build_session() -> HandsSession:
    """Everything the server needs, built on the worker thread.

    The broker may legitimately be absent here — it is a separate process,
    started at logon by a per-user `Run` registry value on Windows or a
    LaunchAgent on macOS — so `from_disk()` returning None is not an error;
    the session re-probes when a protected step actually arrives."""
    config = load_config()
    session_id = os.environ.get("FIREKEEP_SESSION_ID") or uuid.uuid4().hex[:12]
    return HandsSession(
        backend=load_backend(),
        broker=BrokerClient.from_disk(),
        link=KeepLink(
            agent_id=os.environ.get("NEXUS_AGENT_ID") or "hands",
            machine_id=machine_id(),
            session_id=session_id,
        ),
        browser=Browser(kind=config.browser),
        config=config,
        policy=load_policy(),
        session_id=session_id,
    )


def _invoke(session: HandsSession, name: str, arguments: dict):
    if name == "hands_status":
        return session.status()
    if name == "hands_task_start":
        return session.task_start(arguments["goal"], arguments.get("apps"))
    if name == "hands_observe":
        return session.observe(
            detail=arguments.get("detail", "controls"),
            app=arguments.get("app"),
            region=arguments.get("region"),
            max_nodes=arguments.get("max_nodes"),
        )
    if name == "hands_find":
        return session.find(
            arguments["query"], role=arguments.get("role"), app=arguments.get("app"),
            limit=arguments.get("limit", 10),
        )
    if name == "hands_act":
        return session.act(arguments["action"], permit=arguments.get("permit"))
    if name == "hands_request_permit":
        return session.request_permit(arguments["challenge"], wait_s=arguments.get("wait_s", 45))
    if name == "hands_browser":
        return session.browser_op(
            arguments["op"],
            **{k: v for k, v in arguments.items() if k != "op"},
        )
    if name == "hands_task_end":
        return session.task_end(arguments["outcome"], arguments.get("summary", ""))
    raise HandsError("invalid_action", f"unknown tool {name!r}")


def dispatch(session: HandsSession, name: str, arguments: dict) -> list[t.ContentBlock]:
    """One tool call, start to finish, with nothing able to escape.

    Screenshot bytes never go into the JSON: they ride as a separate image
    block, so the text result stays readable and the same PNG is not carried
    twice."""
    try:
        result = _invoke(session, name, dict(arguments or {}))
    except HandsError as exc:
        result = {"ok": False, "error": f"{exc.code}: {exc}"}
    except KeyError as exc:  # a required argument the client did not send
        result = {"ok": False, "error": f"invalid_action: missing argument {exc}"}
    except Exception as exc:  # noqa: BLE001 — a crash here would kill the connection
        hooklog.log_failure("hands", f"{name} failed: {exc}", exc)
        result = {"ok": False, "error": f"backend: {exc}"}

    png = result.pop("screenshot_png", None) if isinstance(result, dict) else None
    blocks: list[t.ContentBlock] = [
        t.TextContent(type="text", text=json.dumps(result, default=str))
    ]
    if png:
        blocks.append(t.ImageContent(
            type="image",
            data=base64.b64encode(png).decode("ascii"),
            mimeType="image/png",
        ))
    return blocks


def build_server(session: HandsSession, worker: Worker) -> Server:
    """The MCP server bound to one session and one worker thread.

    The version is the wheel's own: left unset, the SDK advertises its own
    version as the server's, and a client asking "which Hands is this?" would
    be told which `mcp` it was built against."""
    server = Server(SERVER_NAME, version=__version__)

    @server.list_tools()
    async def list_tools() -> list[t.Tool]:
        return list(TOOLS)

    @server.call_tool()
    async def call_tool(name: str, arguments: dict) -> list[t.ContentBlock]:
        return await worker.call(dispatch, session, name, arguments)

    return server


def _raise_on_sigterm(signum, _frame):
    """SIGTERM's default action ends the process outright, running no
    `finally` anywhere — which is exactly how a lease gets stranded. Turning
    it into the same KeyboardInterrupt a Ctrl+C produces gives `serve` its
    one chance to hand the machine back.

    This buys nothing on Windows, and the honest reading matters: an external
    `os.kill(pid, SIGTERM)` there is `TerminateProcess`, which ends the
    process at the kernel and never reaches Python, so no handler of any kind
    can run. The covered shutdown paths on Windows are stdin EOF (the runtime
    closing the pipe, which is the ordinary case) and Ctrl+C. On POSIX this
    handler is what makes a `kill` survivable."""
    raise KeyboardInterrupt(f"signal {signum}")


def _install_sigterm() -> object:
    """Returns the previous handler, or None if it could not be installed
    (not the main thread, or a platform without SIGTERM)."""
    sigterm = getattr(signal, "SIGTERM", None)
    if sigterm is None:
        return None
    try:
        return signal.signal(sigterm, _raise_on_sigterm)
    except (ValueError, OSError, RuntimeError):
        return None


def shutdown(session: HandsSession | None, worker: Worker) -> None:
    """Give the machine back, whatever ended the process.

    Runs the teardown on the worker thread (the session belongs to it) and
    synchronously rather than through the event loop, which by this point may
    already be tearing itself down and cancelling anything awaited. Nothing
    here is allowed to raise: this is the last code that runs."""
    if session is not None:
        try:
            closed = worker.run(session.abandon)
            if closed is not None:
                # What actually happened, not what we hoped: "not held" is the
                # normal answer on an offline machine, and a log that always
                # claimed a release would be the first thing to mislead
                # somebody debugging a lease that outlived its session.
                hooklog.log_failure(
                    "hands",
                    f"shut down with {closed['task_id']} open: closed as abandoned, "
                    f"lease {closed.get('lease', 'unknown')}",
                )
        except Exception as exc:  # noqa: BLE001 — nothing may escape a shutdown
            hooklog.log_failure("hands", f"shutdown teardown failed: {exc}", exc)
    worker.shutdown()


async def serve() -> None:
    from mcp.server.stdio import stdio_server

    worker = Worker()
    session = None
    previous_sigterm = _install_sigterm()
    try:
        # First submission, so this thread is the one COM binds to.
        session = await worker.call(build_session)
        server = build_server(session, worker)
        async with stdio_server() as (read_stream, write_stream):
            await server.run(read_stream, write_stream, server.create_initialization_options())
    finally:
        shutdown(session, worker)
        sigterm = getattr(signal, "SIGTERM", None)
        if previous_sigterm is not None and sigterm is not None:
            try:
                signal.signal(sigterm, previous_sigterm)
            except (ValueError, OSError, RuntimeError):
                pass


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(
        prog=SERVER_NAME,
        description="Run the Firekeep Hands MCP server on stdio.",
    )
    parser.parse_args(argv)
    try:
        asyncio.run(serve())
    except KeyboardInterrupt:
        # Ctrl+C, or the SIGTERM handler above. `serve`'s own `finally` has
        # already handed the machine back by the time this is caught; there is
        # nothing here for a traceback to tell anyone.
        pass


if __name__ == "__main__":
    main()
