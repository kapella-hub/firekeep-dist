#!/usr/bin/env bash
set -euo pipefail

# Firekeep — idempotent auth key bootstrap (SP1a §4.2).
#
# Mints (only if absent):
#   1. FIREKEEP_INTERNAL_KEY  — internal service key (bridge distiller, workers).
#      Scopes: memory:write, session:read, eval:read, eval:write (NOT admin — a leaked
#      internal key cannot mint keys or read vault). Plaintext -> .env.
#   2. DASHBOARD_API_KEY — dashboard nginx proxy key (spec §4.4b: the
#      dashboard IS the owner's admin surface). Scopes: ["*"]. Plaintext -> .env.
#   3. RELAY_INTERNAL_API_KEY — Relay's outbound key for the ONE call it makes
#      into Bridge: POST /sessions/{agent_id}/context, which persists NexusScope
#      decisions for origin:"mcp" sessions (relay/app/scope.py _persist_to_bridge).
#      Bridge gates that route with require_scope_asgi(request, "session:write")
#      (bridge/app/mcp_server.py:561), so that single scope is the whole
#      requirement — deliberately NOT the internal key's set and NOT ["*"].
#      docker-compose.yml already reads it (NR_FIREKEEP_API_KEY:
#      ${RELAY_INTERNAL_API_KEY:-}); nothing minted it, so the var resolved
#      empty and the write went out unkeyed. That was survivable only while
#      auth was off by default: _persist_to_bridge is best-effort and swallows
#      the failure, so with auth ON the decisions would have silently stopped
#      persisting with nothing but a warning in relay's log. Plaintext -> .env.
#   4. Admin key — the owner's key. Scopes: ["*"]. Plaintext printed ONCE,
#      never written to disk.
#
# Redis layout replicates auth/keys.py create_key() EXACTLY:
#   auth:key:{sha256hex}  hash: workspace_id, member_id, device_id,
#                               scopes (JSON array string), created_at,
#                               key_id, credential_id
#   auth:cred:{credential_id} -> sha256hex exact-resolution mapping
#   auth:key_index        zset: member = credential_id, score = unix timestamp
# (no expires_at — bootstrap keys do not expire)
#
# Idempotency:
#   - env-backed keys: if .env carries the key and its hash is registered,
#     nothing happens. If .env has the key but Redis lost it (down -v), the
#     hash is re-registered — same plaintext, NO rotation.
#   - admin key: marker auth:bootstrap:admin_hash records the admin key hash;
#     if that hash is still registered, nothing is minted.
#
# Env overrides (used by tests):
#   ENV_FILE              target env file          (default: ./.env)
#   BOOTSTRAP_REDIS_CMD   redis-cli command line   (default: docker compose exec -T redis redis-cli -n 7)

ENV_FILE="${ENV_FILE:-.env}"
IFS=' ' read -r -a REDIS <<< "${BOOTSTRAP_REDIS_CMD:-docker compose exec -T redis redis-cli -n 7}"

# --- helpers ---------------------------------------------------------------

sha256() { printf '%s' "$1" | sha256sum | awk '{print $1}'; }

mint_key() { echo "nxs_$(openssl rand -hex 24)"; }

now_iso() { date -u +"%Y-%m-%dT%H:%M:%S+00:00"; }

# `|| true`: grep exits 1 on no-match, which set -e -o pipefail would fatal.
env_get() { { grep -E "^$1=" "$ENV_FILE" 2>/dev/null || true; } | head -n1 | cut -d= -f2-; }

env_set() {
    if grep -qE "^$1=" "$ENV_FILE" 2>/dev/null; then
        sed -i "s|^$1=.*|$1=$2|" "$ENV_FILE"
    else
        printf '%s=%s\n' "$1" "$2" >> "$ENV_FILE"
    fi
}

ensure_deployment_id() {  # $1=env var  $2=prefix
    local var="$1" prefix="$2" value
    value="$(env_get "$var")"
    if [ -z "$value" ]; then
        value="${prefix}-$(openssl rand -hex 16)"
        env_set "$var" "$value"
        echo "[GENERATED] $var" >&2
    elif [[ ! "$value" =~ ^[A-Za-z0-9._-]+$ ]] || [ "${#value}" -gt 128 ]; then
        echo "ERROR: $var must contain only letters, digits, dot, underscore or hyphen (max 128 chars)" >&2
        exit 1
    fi
    printf '%s' "$value"
}

key_registered() { [ "$("${REDIS[@]}" EXISTS "auth:key:$1")" = "1" ]; }

register_hash() {  # $1=hash  $2=device_id  $3=scopes-json
    local hash="$1" credential_id
    credential_id="$(openssl rand -hex 8)"
    "${REDIS[@]}" HSET "auth:key:${hash}" \
        workspace_id "$WORKSPACE_ID" \
        member_id "$OWNER_MEMBER_ID" \
        device_id "$2" \
        credential_id "$credential_id" \
        scopes "$3" \
        created_at "$(now_iso)" \
        key_id "$credential_id" > /dev/null
    "${REDIS[@]}" SET "auth:cred:${credential_id}" "$hash" > /dev/null
    "${REDIS[@]}" ZADD auth:key_index "$(date -u +%s)" "$credential_id" > /dev/null
}

backfill_credential_mappings() {
    local credential_id mapped candidate stored_id count match hash ttl
    while IFS= read -r credential_id; do
        [ -n "$credential_id" ] || continue
        mapped="$("${REDIS[@]}" GET "auth:cred:${credential_id}")"
        [ -z "$mapped" ] || continue
        count=0; match=""
        while IFS= read -r candidate; do
            [ -n "$candidate" ] || continue
            stored_id="$("${REDIS[@]}" HGET "$candidate" credential_id)"
            [ -n "$stored_id" ] || stored_id="$("${REDIS[@]}" HGET "$candidate" key_id)"
            if [ "$stored_id" = "$credential_id" ]; then
                match="$candidate"
                count=$((count + 1))
            fi
        done < <("${REDIS[@]}" --scan --pattern "auth:key:${credential_id}*")
        if [ "$count" -eq 1 ]; then
            hash="${match#auth:key:}"
            "${REDIS[@]}" SET "auth:cred:${credential_id}" "$hash" > /dev/null
            ttl="$("${REDIS[@]}" TTL "$match")"
            [ "$ttl" -gt 0 ] && "${REDIS[@]}" EXPIRE "auth:cred:${credential_id}" "$ttl" > /dev/null
            "${REDIS[@]}" HSET "$match" credential_id "$credential_id" \
                device_id "$("${REDIS[@]}" HGET "$match" agent_id)" > /dev/null
            echo "[BACKFILLED] auth:cred:${credential_id}"
        elif [ "$count" -gt 1 ]; then
            echo "[REFUSED] auth:cred:${credential_id}: ${count} legacy records are ambiguous" >&2
        fi
    done < <("${REDIS[@]}" ZRANGE auth:key_index 0 -1)
}

MINTED=0

ensure_env_key() {  # $1=env var  $2=device_id  $3=scopes-json
    local var="$1" device_id="$2" scopes="$3" key hash
    key="$(env_get "$var")"
    if [ -z "$key" ]; then
        key="$(mint_key)"
        env_set "$var" "$key"
        register_hash "$(sha256 "$key")" "$device_id" "$scopes"
        MINTED=$((MINTED + 1))
        echo "[MINTED] $var  (device_id=$device_id scopes=$scopes)"
    else
        hash="$(sha256 "$key")"
        if key_registered "$hash"; then
            echo "[OK] $var already provisioned"
        else
            register_hash "$hash" "$device_id" "$scopes"
            echo "[RE-REGISTERED] $var hash (Redis had lost it; plaintext unchanged)"
        fi
    fi
}

# --- preconditions (fail loudly — Reliability Principle) --------------------

if ! command -v openssl > /dev/null; then
    echo "ERROR: openssl is required to mint keys" >&2
    exit 1
fi

touch "$ENV_FILE"
WORKSPACE_ID="$(ensure_deployment_id FIREKEEP_WORKSPACE_ID workspace)"
OWNER_MEMBER_ID="$(ensure_deployment_id FIREKEEP_OWNER_MEMBER_ID member)"

if ! "${REDIS[@]}" PING 2>/dev/null | grep -q PONG; then
    echo "ERROR: cannot reach Redis DB 7 via: ${REDIS[*]}" >&2
    echo "       (is the stack up? try: docker compose up -d redis)" >&2
    exit 1
fi

# --- 1+2: env-backed service keys -------------------------------------------

ensure_env_key FIREKEEP_INTERNAL_KEY  firekeep-internal  '["memory:write","session:read","eval:read","eval:write"]'
ensure_env_key DASHBOARD_API_KEY firekeep-dashboard '["*"]'
ensure_env_key RELAY_INTERNAL_API_KEY firekeep-relay '["session:write"]'

# --- 4: owner admin key (printed once, never stored) -------------------------
#
# NOTE for anyone adding a key above: mint it through ensure_env_key, never a
# hand-rolled echo. ensure_env_key prints only the VAR NAME, device_id and
# scopes — never the plaintext — which is what makes the admin key below the
# only `nxs_...` literal in this script's output. install.sh relies on exactly
# that to re-surface the admin key in its closing summary (it greps its
# captured bootstrap output for a single nxs_ token). A second plaintext in
# this stream would both leak that key into install.sh's captured stdout and
# make the summary print the wrong one.

ADMIN_MARKER="auth:bootstrap:admin_hash"
ADMIN_HASH="$("${REDIS[@]}" GET "$ADMIN_MARKER")"
if [ -n "$ADMIN_HASH" ] && key_registered "$ADMIN_HASH"; then
    ADMIN_CREDENTIAL_ID="$("${REDIS[@]}" HGET "auth:key:${ADMIN_HASH}" credential_id)"
    echo "[OK] admin key already provisioned (credential_id ${ADMIN_CREDENTIAL_ID})"
else
    ADMIN_KEY="$(mint_key)"
    ADMIN_HASH="$(sha256 "$ADMIN_KEY")"
    register_hash "$ADMIN_HASH" "admin" '["*"]'
    "${REDIS[@]}" SET "$ADMIN_MARKER" "$ADMIN_HASH" > /dev/null
    MINTED=$((MINTED + 1))
    echo ""
    echo "============================================================"
    echo "  ADMIN API KEY — shown ONCE, not written to disk."
    echo "  Store it in your password manager now:"
    echo ""
    echo "    $ADMIN_KEY"
    echo ""
    echo "  Use it with deploy/firekeep-admin to issue teammate keys."
    echo "============================================================"
fi

# Upgrade path for credentials created before independent ID mappings existed.
# Ambiguity is refused rather than guessed; every new record above already has
# the mapping, so idempotent runs add nothing.
backfill_credential_mappings

echo ""
echo "bootstrap-keys: done ($MINTED key(s) minted)"
